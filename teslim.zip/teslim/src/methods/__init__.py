"""Link prediction method implementations."""
